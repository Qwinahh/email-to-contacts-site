/* Email to Contacts, browser extension: the background worker. Signs in to Google and saves contacts.
   The page script (content.js) sends { type: 'check' | 'save', details }; this answers with
   { status, link } or { error }. The Google token is kept in session storage only, never on disk. */
importScripts('config.js', 'rules.js'); // rules.js: buildPerson and contactLink, shared with the Gmail add-on

const PEOPLE = 'https://people.googleapis.com/v1';
const USERINFO = 'https://www.googleapis.com/oauth2/v3/userinfo';
// contacts to save; email only to learn which account was chosen (see googleToken).
const SCOPE = 'https://www.googleapis.com/auth/contacts email';

// ----- Google sign-in -----

// Google tokens last about an hour. With several Google accounts in the browser, Google asks which
// one to use unless told, so the chosen account's address is remembered (local storage, the address
// only) and passed as login_hint: the hourly renewal then happens quietly. Seen live on 3 Nov.
async function googleToken(interactive) {
  const { google } = await chrome.storage.session.get('google');
  if (google && google.expiresAt - Date.now() > 60000) return google.token;
  const { googleAccount } = await chrome.storage.local.get('googleAccount');
  const params = {
    client_id: self.EMAIL_TO_CONTACTS_CONFIG.googleClientId,
    response_type: 'token',
    redirect_uri: chrome.identity.getRedirectURL(),
    scope: SCOPE,
    include_granted_scopes: 'true',
  };
  if (googleAccount) params.login_hint = googleAccount;
  if (!interactive) params.prompt = 'none';
  let redirect;
  try {
    redirect = await chrome.identity.launchWebAuthFlow({ url: 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams(params), interactive: interactive });
  } catch (err) {
    if (!interactive) return null;
    throw new Error('Google sign-in did not finish. If a Google window opened, choose your account there, then click Save again.');
  }
  const reply = new URLSearchParams(new URL(redirect).hash.slice(1));
  if (!reply.get('access_token')) {
    if (!interactive) return null;
    throw new Error('Google sign-in did not finish: ' + (reply.get('error') || 'no token'));
  }
  const token = reply.get('access_token');
  await chrome.storage.session.set({ google: { token: token, expiresAt: Date.now() + Number(reply.get('expires_in') || 3600) * 1000 } });
  if (!googleAccount) await rememberAccount(token);
  return token;
}

async function rememberAccount(token) {
  try {
    const res = await fetch(USERINFO, { headers: { Authorization: 'Bearer ' + token } });
    const info = res.ok ? await res.json() : {};
    if (info.email) await chrome.storage.local.set({ googleAccount: String(info.email) });
  } catch (err) { /* only a convenience: sign-in still works without it */ }
}

async function signOut() {
  await chrome.storage.session.remove('google');
  await chrome.storage.local.remove('googleAccount');
}

// ----- Google Contacts -----

async function people(token, method, path, body) {
  const res = await fetch(PEOPLE + path, {
    method: method,
    headers: Object.assign({ Authorization: 'Bearer ' + token }, body ? { 'Content-Type': 'application/json' } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401) await signOut();
    const err = new Error((json.error && json.error.message) || 'Google Contacts error ' + res.status);
    err.status = res.status;
    throw err;
  }
  return json;
}

// The existing contact's resource name, or null. The quick search can miss contacts until its cache
// warms up, so when it finds nothing the full contact list is checked too (as in the Gmail add-on).
async function findContact(token, email) {
  email = String(email || '').trim().toLowerCase();
  if (!email) return null;
  const has = (p) => (p.emailAddresses || []).some((e) => String(e.value).toLowerCase() === email);
  await people(token, 'GET', '/people:searchContacts?query=&readMask=emailAddresses');
  const found = await people(token, 'GET', '/people:searchContacts?' + new URLSearchParams({ query: email, readMask: 'emailAddresses' }));
  const hit = (found.results || []).find((r) => has(r.person));
  if (hit) return hit.person.resourceName;
  let pageToken = '';
  do {
    const page = await people(token, 'GET', '/people/me/connections?' + new URLSearchParams({ personFields: 'emailAddresses', pageSize: '1000', pageToken: pageToken }));
    const match = (page.connections || []).find(has);
    if (match) return match.resourceName;
    pageToken = page.nextPageToken || '';
  } while (pageToken);
  return null;
}

async function handle(msg) {
  if (msg.type === 'check') {
    const token = await googleToken(false);
    if (!token) return { status: 'signed-out' };
    const existing = await findContact(token, msg.details.email);
    return existing ? { status: 'exists', link: contactLink(existing) } : { status: 'new' };
  }
  if (msg.type === 'save') {
    const d = msg.details;
    if (!String(d.name || '').trim() && !String(d.email || '').trim()) return { status: 'missing' };
    const token = await googleToken(true);
    const existing = await findContact(token, d.email);
    if (existing) return { status: 'exists', link: contactLink(existing) };
    const created = await people(token, 'POST', '/people:createContact', buildPerson(d));
    return { status: 'saved', link: contactLink(created.resourceName) };
  }
  if (msg.type === 'signin') return { status: (await googleToken(true)) ? 'signed-in' : 'signed-out' };
  if (msg.type === 'signout') { await signOut(); return { status: 'signed-out' }; }
  if (msg.type === 'status') return { status: (await googleToken(false)) ? 'signed-in' : 'signed-out' };
  return { error: 'Unknown request' };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg).then(sendResponse, (err) => sendResponse({ error: err.message }));
  return true; // answer asynchronously
});

// The toolbar button: open the panel on this page. On an email site not in the list, add the
// page script first (allowed for this tab only, because the user clicked).
chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'open' });
  } catch (err) {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['parser.js', 'contact-core.js', 'content.js'] });
    await chrome.tabs.sendMessage(tab.id, { type: 'open' });
  }
});

if (typeof module === 'object' && module.exports) module.exports = { handle, findContact, googleToken };
