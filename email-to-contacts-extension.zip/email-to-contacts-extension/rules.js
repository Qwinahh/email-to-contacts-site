// Email to Contacts: who gets added, and what the new contact looks like. Shared by the personal
// version (Code.gs) and the shareable sheet version (Sheet.gs). Pure: no Google calls, so it can be tested.

// Words in the part before the @ that mean the sender is almost never a person you'd want in your
// phone, wherever they appear (noreply@, messages-noreply@, billing.alerts@ ...).
const AUTOMATED_SENDER = /^(?:[^@]*[-+._])?(?:no-?reply|do-?not-?reply|donotreply|notifications?|notify|alerts?|mailer-daemon|postmaster|bounces?|newsletters?|news|marketing|updates?|digest|billing|invoices?|receipts?|accounts?|support|help|info|hello|team|admin|system|automated)(?:[-+._][^@]*)?@/i;
// Bulk email services that send newsletters and notifications on others' behalf.
const BULK_SENDER_DOMAIN = /@(?:[^@]*\.)?(?:mcsv\.net|mailchimp\.com|mcdlv\.net|sendgrid\.net|amazonses\.com|mailgun\.org|mailgun\.net|hubspotemail\.net|hs-email\.net|sparkpostmail\.com|mandrillapp\.com|cmail\d*\.com|createsend\.com|exacttarget\.com|rsgsv\.net)$/i;

function parseFrom(from) {
  const s = String(from || '').trim();
  const m = s.match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/);
  if (m) return { name: m[1].trim(), email: m[2].trim().toLowerCase() };
  return { name: '', email: s.replace(/[<>]/g, '').trim().toLowerCase() };
}

// Decide whether an email's sender should be added.
// info: { from, me, body, headers: { listUnsubscribe, listId, precedence, autoSubmitted } }
function evaluate(info, settings) {
  settings = settings || { requirePhone: true };
  const sender = parseFrom(info.from);
  const headers = info.headers || {};
  if (!sender.email || sender.email.indexOf('@') < 1) return { add: false, reason: 'no sender address' };
  if (sender.email === String(info.me || '').toLowerCase()) return { add: false, reason: 'your own email' };
  if (BULK_SENDER_DOMAIN.test(sender.email)) return { add: false, reason: 'sent by a bulk email service' };
  if (AUTOMATED_SENDER.test(sender.email)) return { add: false, reason: 'automated or shared sender address' };
  if (headers.listUnsubscribe || headers.listId) return { add: false, reason: 'newsletter or mailing list' };
  if (/\b(?:bulk|list|junk)\b/i.test(headers.precedence || '')) return { add: false, reason: 'bulk email' };
  if (headers.autoSubmitted && !/^no$/i.test(headers.autoSubmitted.trim())) return { add: false, reason: 'automatic reply' };
  const card = parseEmail('From: ' + info.from + '\n\n' + (info.body || ''));
  card.email = card.email || sender.email;
  card.name = card.name || sender.name;
  // The reader drops a signature that names someone else (a forward, an assistant); say so rather than "no phone".
  if ((card.warnings || []).some((w) => /^Signature name differs/.test(w))) return { add: false, reason: "signature name doesn't match the sender" };
  if (settings.requirePhone && !(card.phones || []).length) return { add: false, reason: 'no phone number in the signature' };
  if (!card.name) return { add: false, reason: 'no name found' };
  return { add: true, card: card };
}

const PHONE_TYPES = { mobile: 'mobile', work: 'work', home: 'home', fax: 'workFax', other: 'other' };

// The People API contact for a card, leaving out empty fields.
function buildPerson(card) {
  const clean = (v) => String(v == null ? '' : v).trim();
  const words = clean(card.name).split(/\s+/).filter(Boolean);
  const person = {};
  if (words.length) person.names = [words.length > 1 ? { givenName: words.slice(0, -1).join(' '), familyName: words[words.length - 1] } : { givenName: words[0] }];
  if (clean(card.email)) person.emailAddresses = [{ value: clean(card.email), type: 'work' }];
  const phones = (card.phones || []).filter((p) => clean(p.number)).map((p) => ({ value: clean(p.number), type: PHONE_TYPES[clean(p.label).toLowerCase()] || 'other' }));
  if (phones.length) person.phoneNumbers = phones;
  if (clean(card.company) || clean(card.title)) {
    const org = {};
    if (clean(card.company)) org.name = clean(card.company);
    if (clean(card.title)) org.title = clean(card.title);
    person.organizations = [org];
  }
  return person;
}

// "people/c123" -> a link that opens the contact in Google Contacts.
function contactLink(resourceName) {
  return 'https://contacts.google.com/person/' + String(resourceName || '').replace(/^people\//, '');
}

if (typeof module === 'object' && module.exports) {
  module.exports = { evaluate, parseFrom, buildPerson, contactLink };
}
