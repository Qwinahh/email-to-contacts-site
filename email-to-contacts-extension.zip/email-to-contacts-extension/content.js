/* Email to Contacts, browser extension: the part that runs inside the email website.
   It finds the email you're reading (Gmail and Outlook on the web), or uses text you've selected
   (any email site, including iCloud Mail and Yahoo), and shows a "Save to contacts" button. The card
   is drawn inside a closed shadow root so the site's styles can't change it and it can't change the
   site. All text is set with textContent or input values, never as HTML. */
(function () {
  'use strict';
  if (window.__emailToContactsLoaded) return;
  window.__emailToContactsLoaded = true;

  const Core = globalThis.EmailToContacts;
  const parse = globalThis.parseEmail;
  const EMAIL = /[A-Z0-9._%+'-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;

  // ----- Finding the open email -----

  // Each reader returns { messages: [{ from: { displayName, emailAddress }, bodyEl }], me }.
  const READERS = {
    gmail() {
      const messages = [...document.querySelectorAll('div.adn')].map((m) => {
        const sender = m.querySelector('span.gD[email]');
        const body = m.querySelector('div.a3s');
        if (!sender || !body || !body.offsetParent) return null;
        return { from: { displayName: sender.getAttribute('name') || sender.textContent, emailAddress: sender.getAttribute('email') }, bodyEl: body };
      }).filter(Boolean);
      const account = (document.querySelector('a[aria-label*="Google Account"]') || { getAttribute: () => '' }).getAttribute('aria-label') || '';
      return { messages: messages, me: (account.match(/\(([^()\s]+@[^()\s]+)\)/) || [])[1] || '' };
    },
    outlook() {
      const messages = [...document.querySelectorAll('div[aria-label="Message body"]')].filter((b) => b.offsetParent).map((body) => {
        let box = body.parentElement;
        let from = null;
        while (box && !(from = box.querySelector('span[aria-label^="From:"]'))) box = box.parentElement;
        if (!from) return null;
        return { from: splitSender(from.textContent, from.getAttribute('aria-label').replace(/^From:\s*/, '')), bodyEl: body };
      }).filter(Boolean);
      return { messages: messages, me: '' };
    },
    // iCloud Mail: the app is a same-origin frame; each message's text is in a frame from another
    // address that frame.js reads and reports (see frameReports). The header beside it shows the
    // sender's name only: iCloud doesn't put their address on the page.
    icloud() {
      const app = icloudApp();
      if (!app) return { messages: [], me: '' };
      const messages = [];
      for (const frame of app.doc.querySelectorAll('iframe')) {
        const report = reportFor(frame);
        if (!report || !report.text.trim() || !frame.offsetParent) continue;
        let box = frame.parentElement;
        let sender = null;
        while (box && box !== app.doc.body && !(sender = box.querySelector('span.contact-token[role="button"]'))) box = box.parentElement;
        const name = sender ? sender.textContent.trim() : '';
        messages.push({
          from: EMAIL.test(name) ? { displayName: '', emailAddress: name } : { displayName: name, emailAddress: '' },
          bodyEl: frame,
          offset: app.offset,
          text: report.text,
        });
      }
      return { messages: messages, me: '' };
    },
  };

  function readerFor(host) {
    if (host === 'mail.google.com') return READERS.gmail;
    if (/^outlook\.(live|office|office365)\.com$|^outlook\.cloud\.microsoft$/.test(host)) return READERS.outlook;
    if (host === 'www.icloud.com') return READERS.icloud;
    return null; // other sites: selected text only
  }

  // ----- iCloud Mail's message frames -----

  const ICLOUD_FRAMES = 'https://www-mail.icloud-sandbox.com';
  const frameReports = new Map(); // frame window -> { text, selection, at }

  function icloudApp() {
    const frame = document.querySelector('iframe[src*="/applications/mail"]');
    let doc = null;
    try { doc = frame && frame.contentDocument; } catch (e) { /* not readable */ }
    if (!doc) return null;
    const r = frame.getBoundingClientRect();
    return { doc: doc, offset: { x: r.left, y: r.top } };
  }

  window.addEventListener('message', (event) => {
    if (event.origin !== ICLOUD_FRAMES || !event.data || event.data.emailToContacts !== 'icloud-frame') return;
    const size = event.data.size || {};
    frameReports.set(event.source, { text: String(event.data.text || ''), selection: String(event.data.selection || ''), w: Number(size.w) || 0, h: Number(size.h) || 0, at: Date.now() });
  });

  // A frame's latest report. The extension's view of a frame window isn't always the same object as
  // the one a message arrives from (seen live in Chrome, 2 Nov), so match by size when identity fails,
  // and give an open message's frame (taller than a collapsed one) the newest report as a last resort.
  function reportFor(frame) {
    const direct = frameReports.get(frame.contentWindow);
    if (direct) return direct;
    const reports = [...frameReports.values()].sort((a, b) => b.at - a.at);
    const sized = reports.find((r) => r.w === frame.clientWidth && r.h === frame.clientHeight);
    if (sized) return sized;
    return frame.offsetHeight > 200 ? reports[0] || null : null;
  }

  // Text selected inside an iCloud message frame (the page's own selection can't see it).
  function frameSelection() {
    let latest = null;
    for (const r of frameReports.values()) if (r.selection.trim() && (!latest || r.at > latest.at)) latest = r;
    return latest ? latest.selection : '';
  }

  // "Name<email>" or "Name <email>" as shown by Outlook.
  function splitSender(text, fallbackName) {
    const m = String(text || '').match(/^\s*(.*?)\s*<([^>]+)>\s*$/);
    if (m) return { displayName: m[1] || fallbackName || '', emailAddress: m[2] };
    const email = (String(text || '').match(EMAIL) || [''])[0];
    return { displayName: email ? fallbackName || '' : String(text || '').trim(), emailAddress: email };
  }

  // How much of an element is on screen. offset: where its document sits in this page (iCloud).
  function visibleArea(el, offset) {
    const r = el.getBoundingClientRect();
    const dx = offset ? offset.x : 0;
    const dy = offset ? offset.y : 0;
    const w = Math.max(0, Math.min(r.right + dx, window.innerWidth) - Math.max(r.left + dx, 0));
    const h = Math.max(0, Math.min(r.bottom + dy, window.innerHeight) - Math.max(r.top + dy, 0));
    return w * h;
  }

  // The message you're looking at: from someone other than you, and the most visible on screen.
  function pickMessage(messages, me) {
    const mine = (m) => !!me && String(m.from.emailAddress).toLowerCase() === me.toLowerCase();
    const candidates = messages.filter((m) => !mine(m));
    const pool = candidates.length ? candidates : messages;
    const area = (m) => visibleArea(m.bodyEl, m.offset);
    return pool.reduce((best, m) => (!best || area(m) > area(best) ? m : best), null);
  }

  function openEmail() {
    const reader = readerFor(location.hostname);
    if (!reader) return null;
    const { messages, me } = reader();
    const m = pickMessage(messages, me);
    return m ? { from: m.from, body: m.text != null ? m.text : m.bodyEl.innerText, me: me } : null;
  }

  function fromSelection(text) {
    text = String(text || '').trim();
    if (text.length < 6 || !/\d{3}|@/.test(text)) return null;
    return { from: { displayName: '', emailAddress: (text.match(EMAIL) || [''])[0] }, body: text, me: '' };
  }

  // ----- The button and card -----

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;right:20px;bottom:20px;z-index:2147483646;';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; font: 14px/1.4 "Segoe UI", -apple-system, BlinkMacSystemFont, Roboto, sans-serif; }
      .pill { display: flex; align-items: center; gap: 8px; padding: 9px 16px 9px 12px; border: 0; border-radius: 999px;
        background: #0f6cbd; color: #fff; font-weight: 600; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,.25); }
      .pill img { width: 20px; height: 20px; }
      .card { width: 320px; max-height: calc(100vh - 40px); overflow: auto; padding: 14px 16px 16px; border-radius: 12px;
        background: #fff; color: #1f1f1f; box-shadow: 0 4px 24px rgba(0,0,0,.28); }
      .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
      h1 { margin: 0; font-size: 15px; font-weight: 600; }
      .close { border: 0; background: none; font-size: 20px; line-height: 1; cursor: pointer; color: #5f6368; padding: 2px 6px; }
      .note { background: #fff4ce; padding: 7px 9px; border-radius: 6px; margin: 0 0 10px; }
      label { display: block; font-size: 12px; color: #5f6368; margin: 0 0 8px; }
      input { display: block; width: 100%; margin-top: 3px; padding: 6px 8px; border: 1px solid #c4c7c5; border-radius: 6px; color: #1f1f1f; background: #fff; }
      .save { margin-top: 4px; padding: 8px 18px; border: 0; border-radius: 6px; background: #0f6cbd; color: #fff; font-weight: 600; cursor: pointer; }
      .save:disabled { opacity: .6; cursor: default; }
      .status { margin: 8px 0 0; color: #5f6368; }
      .status.error { color: #a4262c; }
      .where { margin: 10px 0 0; font-size: 12px; color: #5f6368; }
      a { color: #0f6cbd; }
      [hidden] { display: none !important; }
      @media (prefers-color-scheme: dark) {
        .card { background: #202124; color: #e8eaed; }
        input { background: #202124; color: #e8eaed; border-color: #5f6368; }
        label, .status, .where, .close { color: #b0b3b8; }
        .note { background: #433519; }
        a { color: #8ab4f8; }
      }
    </style>
    <button class="pill" part="pill" hidden><img alt=""><span>Save to contacts</span></button>
    <div class="card" hidden>
      <div class="top"><h1>Save to contacts</h1><button class="close" title="Close" aria-label="Close">×</button></div>
      <p class="note" hidden></p>
      <form>
        <label>Name <input name="name" autocomplete="off"></label>
        <label>Email <input name="email" type="email" autocomplete="off"></label>
        <div class="phones"></div>
        <label>Job title <input name="title" autocomplete="off"></label>
        <label>Company <input name="company" autocomplete="off"></label>
        <button class="save" type="submit">Save to contacts</button>
      </form>
      <p class="status" hidden></p>
      <p class="where">Saves a contact card to this computer. Nothing is sent anywhere.</p>
    </div>`;
  const $ = (sel) => root.querySelector(sel);
  // form.name and form.title are the form's own attributes, so look inputs up by name.
  const field = (name) => $('form').elements.namedItem(name);
  $('.pill img').src = chrome.runtime.getURL('icons/icon-32.png');
  (document.body || document.documentElement).appendChild(host);

  let current = null;     // the open email, or null
  let currentKey = '';
  let phoneLabels = [];
  let selectionAtPress = '';

  function setStatus(text, isError) {
    const s = $('.status');
    s.textContent = text;
    s.className = 'status' + (isError ? ' error' : '');
    s.hidden = !text;
  }

  function showPill(show) {
    $('.pill').hidden = !show || !$('.card').hidden;
  }

  function render(d) {
    $('.note').textContent = d.notes;
    $('.note').hidden = !d.notes;
    $('form').hidden = false;
    field('name').value = d.name;
    field('email').value = d.email;
    field('title').value = d.title;
    field('company').value = d.company;
    const phones = d.phones.length ? d.phones : [{ label: 'mobile', number: '' }];
    phoneLabels = phones.map((p) => p.label || 'other');
    const box = $('.phones');
    box.textContent = '';
    phones.forEach((p, i) => {
      const label = document.createElement('label');
      label.textContent = Core.PHONE_LABELS[phoneLabels[i]] || 'Phone';
      const input = document.createElement('input');
      input.name = 'phone' + i;
      input.type = 'tel';
      input.autocomplete = 'off';
      input.value = p.number;
      label.appendChild(input);
      box.appendChild(label);
    });
    $('.save').disabled = false;
    setStatus('');
  }

  function showResult(name, message, link) {
    $('form').hidden = true;
    $('.note').hidden = true;
    const s = $('.status');
    s.className = 'status';
    s.hidden = false;
    s.textContent = '';
    const strong = document.createElement('strong');
    strong.textContent = name;
    s.append(strong, document.createElement('br'), message + ' ');
    if (link) {
      const a = document.createElement('a');
      a.href = link;
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = 'Open contact';
      s.append(a);
    }
  }

  function ask(message) {
    return new Promise((resolve) => chrome.runtime.sendMessage(message, (reply) => resolve(reply || { error: chrome.runtime.lastError ? chrome.runtime.lastError.message : 'No reply' })));
  }

  async function openCard(source) {
    $('.card').hidden = false;
    showPill(false);
    if (!source) {
      $('form').hidden = true;
      $('.note').hidden = true;
      return setStatus('Open an email, or select the sender’s signature, then click the button again.');
    }
    const d = Core.readDetails(source.from, source.body, source.me, parse);
    if (!d.email) d.notes = (d.notes ? d.notes + ' ' : '') + 'No email address was found for them; type it in if you have it.';
    render(d);
    // One click: save straight away. The form stays for what can't be saved as read (no name or
    // email, or your own email).
    if ((d.name || d.email) && !/^This email is from you/.test(d.notes)) await save(d);
  }

  // Saves a contact card (.vcf) to the computer: nothing is sent anywhere and there's no sign-in.
  // Opening it adds the person to the computer's contacts (Contacts on a Mac, Outlook on Windows).
  async function save(d) {
    if (!d.name && !d.email) return setStatus('Add a name or an email first.', true);
    const card = Object.assign({}, d, { name: d.name || d.email });
    const url = URL.createObjectURL(new Blob([ContactCard.buildVCard(card)], { type: 'text/vcard' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = ContactCard.fileName(card);
    root.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    showResult(d.name || d.email, 'Contact card saved. Open it from your downloads to add them to your contacts.');
  }

  function closeCard() {
    $('.card').hidden = true;
    showPill(!!current);
  }

  $('.pill').addEventListener('pointerdown', () => { selectionAtPress = String(window.getSelection()) || frameSelection(); });
  $('.pill').addEventListener('click', () => openCard(fromSelection(selectionAtPress) || current));
  $('.close').addEventListener('click', closeCard);
  $('form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const v = (name) => field(name).value.trim();
    await save({
      name: v('name'), email: v('email'), title: v('title'), company: v('company'),
      phones: phoneLabels.map((label, i) => ({ label: label, number: v('phone' + i) })).filter((p) => p.number),
    });
  });

  // The toolbar button, or the extension being added to this page by it.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'open') openCard(fromSelection(String(window.getSelection()) || frameSelection()) || current);
  });

  // Watch for the open email changing (these sites change pages without reloading).
  function refresh() {
    const email = openEmail();
    const key = email ? email.from.emailAddress + '|' + email.body.length + '|' + location.href : '';
    if (key === currentKey) return;
    currentKey = key;
    current = email;
    if (!$('.card').hidden && !email) closeCard();
    showPill(!!email);
  }
  setInterval(refresh, 1000);
  refresh();

  // For tests on real pages: the readers without the button.
  window.__emailToContactsDebug = { openEmail, splitSender, fromSelection };
})();
