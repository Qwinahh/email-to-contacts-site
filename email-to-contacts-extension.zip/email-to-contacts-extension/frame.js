/* Email to Contacts, browser extension: runs inside iCloud Mail's message frames.
   iCloud shows each message's text in a separate frame from another address
   (www-mail.icloud-sandbox.com), which the main page script can't read. This passes the frame's
   text, and any text selected in it, up to the iCloud Mail page, and only to that page. */
(function () {
  'use strict';
  if (window.__emailToContactsFrame) return;
  window.__emailToContactsFrame = true;

  const TOP_ORIGIN = 'https://www.icloud.com';
  const MAX_TEXT = 20000;
  let timer = null;

  function report() {
    timer = null;
    const text = document.body ? document.body.innerText.slice(0, MAX_TEXT) : '';
    window.top.postMessage({
      emailToContacts: 'icloud-frame',
      text: text,
      selection: String(window.getSelection()).slice(0, MAX_TEXT),
      size: { w: window.innerWidth, h: window.innerHeight }, // lets the page match this report to its frame
    }, TOP_ORIGIN);
  }

  function soon(ms) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(report, ms);
  }

  new MutationObserver(() => soon(500)).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  document.addEventListener('selectionchange', () => soon(250));
  soon(300);
})();
